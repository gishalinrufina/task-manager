
// import React from 'react';
// import './App.css';
// import {BrowserRouter as Router, Route, Routes} from 'react-router-dom';
// import AddTask from './Components/AddTask';
// import TaskList from './Components/TaskList';

// function App(){
//   return(

// <Router>
//   <div className="App">
//     <Routes>
//     <Route path="/" exact element={<TaskList/>}/>
//     <Route path="/add-task" element={<AddTask/>}/>
//     </Routes>
//   </div>
// </Router>
//   );
// }

// export default App;



// import React, { useState } from 'react';
// import './App.css';
// import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
// import AddTask from './Components/AddTask';
// import TaskList from './Components/TaskList';

// function App() {
//   const [tasks, setTasks] = useState([
//     {
//       taskName: 'Default Task',
//       description: 'This is a default task description.',
//       dueDate: '2024-09-30',
//       time: '12:00',
//       location: 'Office',
//       important: 'High priority'
//     }
//   ]);

//   const [taskToEdit, setTaskToEdit] = useState(null);


//   const addTask = (task) => {
//     if(taskToEdit){
//       setTasks(tasks.map(t=>(t===taskToEdit?task:t)));
//       setTaskToEdit(null);
//     }
//     else{
//       setTasks([...tasks, task]);
//     }
    
//   };

//   const deleteTask = (task) =>{
//     if(window.confirm('Are you sure you want to delete this task?')){
//       setTasks(tasks.filter(t=>t!==task));
//     }
//   };

//   return (
//     <Router>
//       <div className="App">
//         <Routes>
//           <Route path="/" exact element={<TaskList tasks={tasks} deleteTask={deleteTask} setTaskToEdit={setTaskToEdit} />} />
//           <Route path="/add-task" element={<AddTask addTask={addTask}  taskToEdit={taskToEdit} /> }/>
//         </Routes>
//       </div>
//     </Router>
//   );
// }

// export default App;
import React, { useState, useEffect } from 'react';
import '@fortawesome/fontawesome-free/css/all.min.css';

import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import AddTask from './Components/AddTask';
import TaskList from './Components/TaskList';
import CompletedTasks from './Components/CompletedTasks';
import Modal from './Components/Modal';



function App() {

  const defaultTask ={
    taskName : "Default Task",
    description: "This is a default task",
    dueDate: '09-10-2024',
    time: '12:30PM',
     };


  const [tasks, setTasks] = useState([defaultTask]);
  const [completedTasks, setCompletedTasks] = useState([]);
  const [taskToEdit, setTaskToEdit] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [showNotification, setShowNotification]= useState(true);
 
  
  
  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }, [darkMode]);

  useEffect(()=>{
    const checkDueDates=()=>{
      const now = new Date();
      const upcomingTasks = tasks.filter(task=>{
        const dueDate = new Date(task.dueDate);
        const timeDiff = dueDate - now;
        const daysDiff = timeDiff / (1000* 3600*24);
        return daysDiff <= 2 && !task.completed;
        //notify if due date is within 2 days
      });
      setNotifications(upcomingTasks);
    };

    checkDueDates();
    const interval = setInterval(checkDueDates, 3600000); //check evry hour
  return()=> clearInterval(interval);
    }, [tasks]);

  const addTask = (task) => {
    if (taskToEdit) {
      setTasks(tasks.map(t => (t === taskToEdit ? task : t)));
      setTaskToEdit(null);
    } else {
      setTasks([...tasks, task]);
    }
  };

  const deleteTask = (task) => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      setTasks(tasks.filter(t => t !== task));
    }
  };

  const markAsComplete = (task) => {
    setTasks(tasks.filter(t => t !== task));
    setCompletedTasks([...completedTasks, { ...task, completed: true }]);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  const closeNotification = ()=>{
    setShowNotification(false);

  }

  return (
    <Router>
      <div className="App">
        {showNotification && notifications.length>0 &&(
          <div className='notification'>
            <button className='close-btn' onClick={closeNotification}>x</button>
            <h2>Upcoming Due Dates</h2>
            <ul>
              {notifications.map((task, index)=>(
                <li key={index}>{task.taskName} is due on {task.dueDate}</li>
              ))}
            </ul>
            </div>
        )}
        
        <Routes>
          <Route path="*" element={<TaskList tasks={tasks} searchQuery={searchQuery} setSearchQuery={setSearchQuery} deleteTask={deleteTask} setTaskToEdit={setTaskToEdit} markAsComplete={markAsComplete} toggleDarkMode={toggleDarkMode} darkMode={darkMode} />} />
          <Route path="/add-task" element={<AddTask addTask={addTask} taskToEdit={taskToEdit} />} />
          <Route path="/completed-tasks" element={<CompletedTasks tasks={completedTasks} />} />
        </Routes>
        <Modal show={showModal} onClose={closeModal}>
          <h2>Wow! You have completed this task!</h2>
        </Modal>
      </div>
    </Router>
  );
}

export default App;
