// import React, { useState } from 'react';
// import {useNavigate} from 'react-router-dom';
// import TaskList from './TaskList.js';
// import '../style.css';

// const AddTask = ({addTask}) =>{

//     const [taskName, setTaskName] = useState('');
//     const [description, setDescription] = useState('');
//     const [dueDate, setDueDate] = useState('');
//     const [time, setTime] = useState('');
//     const [location, setLocation] = useState('');
//     const [important, setImportant] = useState('');
// const history = useNavigate();


//     const handleSubmit = (e) =>{
//         e.preventDefault();
//         const newTask = {taskName, description, dueDate, time, location, important};
//         addTask(newTask);
//         setTaskName('');
//         setDescription('');
//         setDueDate('');
//         setTime('');
//         setLocation('');
//         setImportant('');
//         history.push('/');
        
//     };


//     return(
//         <div className="container">
//             <div className="abstract-art">
//         <div className="AddTask">
//             <form onSubmit={handleSubmit}>
//                 <label>Task Name</label>
//                 <input name="task name" placeholder="new task" type="text" id="task-name" value={taskName} onChange={(e)=>setTaskName(e.target.value)}/>
//            <label>Decription</label>
//            <textarea name="description" placeholder="task-description" type="text-area" id="description" value={description} onChange={(e)=> setDescription(e.target.value)}/>
//            <label>Due date:</label>
//            <input type="date" placeholder="DD/MM/YY" name="due-date" id="due-date" value={dueDate} onChange={(e)=>setDueDate(e.target.value)}/>
//            <label> Time</label>
//            <input type="time" placeholder="00:00" name="time" id="time"  value={time} onChange={(e)=>setTime(e.target.value)}/>
//            <label>Location:</label>
//            <input type="text" placeholder="location" name="location" id="location" value={location} onChange={(e)=> setLocation(e.target.value)}/>
//            <label>Important note:</label>
//            <input type="text" placeholder="Important" name="important-note" id="important note" value={important} onChange={(e)=>setImportant(e.target.value)}/>
      
//            <button type="submit">ADD TASK</button>

//             </form>
//             </div>
//             </div>
//         </div>
//     );
// }

// export default AddTask;



// import React, { useState, useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';
// import '../style.css';

// const AddTask = ({ addTask, taskToEdit }) => {
//   const [taskName, setTaskName] = useState('');
//   const [description, setDescription] = useState('');
//   const [dueDate, setDueDate] = useState('');
//   const [time, setTime] = useState('');
//   const [location, setLocation] = useState('');
//   const [important, setImportant] = useState('');
//   const navigate = useNavigate();

//   useEffect(()=>{
//     if(taskToEdit){
//         setTaskName(taskToEdit.taskName);
//         setDescription(taskToEdit.description);
//         setDueDate(taskToEdit.dueDate);
//         setTime(taskToEdit.time);
//         setLocation(taskToEdit.location);
//         setImportant(taskToEdit.important);
//     }
//   },[taskToEdit]);

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     const newTask = { taskName, description, dueDate, time, location, important };
//     addTask(newTask);
//     setTaskName('');
//     setDescription('');
//     setDueDate('');
//     setTime('');
//     setLocation('');
//     setImportant('');
//     navigate('/');
//   };

//   return (
//     <div className="AddTask">
//       <div className="abstract-art">
//         <div className="AddTask1">
//           <form onSubmit={handleSubmit}>
//             <label>Task Name</label>
//             <input
//               name="task name"
//               placeholder="new task"
//               type="text"
//               id="task-name"
//               value={taskName}
//               onChange={(e) => setTaskName(e.target.value)}
//             />
//             <label>Description</label>
//             <textarea
//               name="description"
//               placeholder="task-description"
//               type="text-area"
//               id="description"
//               value={description}
//               onChange={(e) => setDescription(e.target.value)}
//             />
//             <label>Due date:</label>
//             <input
//               type="date"
//               placeholder="DD/MM/YY"
//               name="due-date"
//               id="due-date"
//               value={dueDate}
//               onChange={(e) => setDueDate(e.target.value)}
//             />
//             <label>Time</label>
//             <input
//               type="time"
//               placeholder="00:00"
//               name="time"
//               id="time"
//               value={time}
//               onChange={(e) => setTime(e.target.value)}
//             />
//             <label>Location:</label>
//             <input
//               type="text"
//               placeholder="location"
//               name="location"
//               id="location"
//               value={location}
//               onChange={(e) => setLocation(e.target.value)}
//             />
//             <label>Important note:</label>
//             <input
//               type="text"
//               placeholder="Important"
//               name="important-note"
//               id="important note"
//               value={important}
//               onChange={(e) => setImportant(e.target.value)}
//             />
//             <button type="submit">{taskToEdit ? 'Update Task':'Add Task'}</button>
//           </form>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default AddTask;


import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../style.css';

const AddTask = ({ addTask, taskToEdit }) => {
  const [taskName, setTaskName] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [time, setTime] = useState('');
  const [location, setLocation] = useState('');
  const [important, setImportant] = useState('');
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();
//useEffect hook allowa to perform side effects in your components, like fetching data, directly maipulating the DOM or setting up subscriptions. It has two arguments. A function that contains the code you want to run as a side effect. And a dependency array - this array lists the variables that the effect depends on. The effect will re-run whenever any of these variables change.
//this useEffect code runs after the component renders i.e, it runs whenever taskToEdit changes. [taskToEdit] - is the dependency array. This means the effect will only run when the taskToEdit changes.
//the condition checks if taskToEdit is not null or undefined
//if the condition is met, then the state setters are called to update the component's state  
useEffect(() => {
    if (taskToEdit) {
      setTaskName(taskToEdit.taskName);
      setDescription(taskToEdit.description);
      setDueDate(taskToEdit.dueDate);
      setTime(taskToEdit.time);
      setLocation(taskToEdit.location);
      setImportant(taskToEdit.important);
    }
  }, [taskToEdit]);

  const validate = () => {
    const newErrors = {}; //newErrors is an object
    if (!taskName) newErrors.taskName = 'Task name is required';  //here taskName is the key 
    if (!description) newErrors.description = 'Description is required';
    if (!dueDate) newErrors.dueDate = 'Due date is required';
    if (!time) newErrors.time = 'Time is required';
    return newErrors;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newErrors = validate();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
    } else {
      const newTask = { taskName, description, dueDate, time, location, important, completed: false };
      addTask(newTask);
      setTaskName('');
      setDescription('');
      setDueDate('');
      setTime('');
      setLocation('');
      setImportant('');
      setErrors({});
      navigate('/');
    }
  };

  return (
    <div className="AddTask container mt-4">
      <div className="card p-4 shadow-sm">
        <h2 className="mb-4">{taskToEdit? 'Update Task' : 'Add New Task'}</h2>
          <form onSubmit={handleSubmit}>
            <div className='form-group mb-3'>
            <label htmlFor='task-name'>Task Name</label>
            <input
              name="task name"
              className='form-control'
              placeholder="new task"
              type="text"
              id="task-name"
              value={taskName}
              onChange={(e) => setTaskName(e.target.value)}
            />
            {errors.taskName && <p className="error">{errors.taskName}</p>}
            </div>
    <div className='form-group mb-3'>
            <label htmlFor='description'>Description</label>
            <textarea
              name="description"
              className='form-control'
              placeholder="task-description"
              type="text-area"
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
            {errors.description && <p className="error">{errors.description}</p>}
            </div>
            <div className='form-group mb-3'>
            <label htmlFor='due-date'>Due date:</label>
            <input
              type="date"
              className='form-control'
              placeholder="DD/MM/YY"
              name="due-date"
              id="due-date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
            />
            {errors.dueDate && <p className="error">{errors.dueDate}</p>}
            </div>
            <div className='form-group mb-3'>
            <label htmlFor='time'>Time</label>
            <input
              type="time"
              className='form-control'
              placeholder="00:00"
              name="time"
              id="time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
            />
            {errors.time && <p className="error">{errors.time}</p>}
            </div>
            <div className='form-group mb-3'>
            <label htmlFor='location'>Location:</label>
            <input
              type="text"
              className='form-control'
              placeholder="location"
              name="location"
              id="location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
            </div>
            <div className='form-group mb-3'>
            <label htmlFor='important'>Important note:</label>
            <input
              type="text"
              className='form-control'
              placeholder="Important"
              name="important-note"
              id="important note"
              value={important}
              onChange={(e) => setImportant(e.target.value)}
            />
            </div>
           {/* if textToEdit is truthy then the Update task will be displayed */}
            <button type="submit" className='btn btn-primary'>{taskToEdit ? 'Update Task' : 'Add Task'}</button>
          </form>
        </div>
      </div>
    
  );
};

export default AddTask;

