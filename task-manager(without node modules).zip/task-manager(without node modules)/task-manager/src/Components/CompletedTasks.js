import React from 'react';
import '../style.css';

const CompletedTasks = ({ tasks }) => {
  return (
    <div className="container mt-4">
      <h1>Completed Tasks</h1>
      <div className="row d-flex justify-content-center align-items-stretch g-4">
        {tasks.map((task, index) => (
          <div className="col-md-4 mb-4 d-flex" key={index}>
            <div className="card flex-fill">
              <div className="card-body">
                <h5 className="card-title">{task.taskName}</h5>
                <p className="card-text">{task.description}</p>
                <p className="card-text"><strong>Due Date:</strong> {task.dueDate}</p>
                <p className="card-text"><strong>Time:</strong> {task.time}</p>
                <p className="card-text"><strong>Location:</strong> {task.location}</p>
                <p className="card-text"><strong>Priority:</strong> {task.important}</p>
                <p className="card-text"><strong>Status:</strong> Completed</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CompletedTasks;
