// import React, {useState} from 'react';
// import '../style.css';

// import AddTask from './AddTask';
// import { Link, Route, Routes } from 'react-router-dom';


// const TaskList = () =>{
//     const [tasks, setTasks] = useState([
//         {taskName: 'Default Task',
//             description: 'This is a default task description.',
//             dueDate: '2024-09-30',
//             time: '12:00',
//             location: 'Office',
//             important: 'High priority'
//         }
//     ]);
//     const addTask= (task) =>{
//         setTasks([...tasks, task]);
//     };
//     return(
//         <div className="task-list-container">
           
//             <ul>
//                 {tasks.map((task, index)=>(
//                     <li key={index}>
//                         <h3>{task.taskName}</h3>
//                         <p>{task.description}</p>
//                         <p>{task.dueDate}</p>
//                         <p>{task.time}</p>
//                         <p>{task.location}</p>
//                         <p>{task.important}</p>
//                     </li>
//                 ))}
//             </ul>
            
//             <Link to="/add-task">
//             <button>Add new Task</button>
//             </Link>
//             <Routes>
//                 <Route path="/add-task" element={<AddTask addTask={addTask} />} />
//             </Routes>

//         </div>
//     );
// };

// export default TaskList;

// import React from 'react';
// import { Link, Route, Routes } from 'react-router-dom';
// import AddTask from './AddTask';
// import '../style.css';

// const TaskList = ({ tasks, deleteTask, setTaskToEdit }) => {
//   return (
//     <div className="container mt-4">
//         <h1>All Tasks</h1>
//       <div className="row  row-cols-md-3 g-4 d-flex justify-content-center align-items-stretch">
//         {tasks.map((task, index) => (
//           <div className="col mb-4" key={index}>
//             <div className="card">
//               <div className="card-body">
//                 <h5 className="card-title">{task.taskName}</h5>
//                 <p className="card-text">{task.description}</p>
//                 <p className="card-text"><strong>Due Date:</strong> {task.dueDate}</p>
//                 <p className="card-text"><strong>Time:</strong> {task.time}</p>
//                 <p className="card-text"><strong>Location:</strong> {task.location}</p>
//                 <p className="card-text"><strong>Priority:</strong> {task.important}</p>
//               <button className='btn btn-warning mr-2' onClick={()=> setTaskToEdit(task)}>Edit</button>
//               <button className='btn btn-danger' onClick={()=>deleteTask(task)}>Delete</button>
              
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>
//       <Link to="/add-task">
//         <button className="btn btn-primary">Add new Task</button>
//       </Link>
//       <Routes>
//         <Route path="/add-task" element={<AddTask />} />
//       </Routes>
//     </div>
//   );
// };

// export default TaskList;


// import React from 'react';
// import { Link, Route, Routes } from 'react-router-dom';
// import AddTask from './AddTask';
// import '../style.css';

// const TaskList = ({ tasks, deleteTask, setTaskToEdit }) => {
//   return (
//     <div className="container mt-4">
//       <h1>All Tasks</h1>
//       <div className="row d-flex justify-content-center align-items-stretch g-4">
//         {tasks.map((task, index) => (
//           <div className="col-md-4 mb-4 d-flex" key={index}>
//             <div className="card flex-fill">
//               <div className="card-body">
//                 <h5 className="card-title">{task.taskName}</h5>
//                 <p className="card-text">{task.description}</p>
//                 <p className="card-text"><strong>Due Date:</strong> {task.dueDate}</p>
//                 <p className="card-text"><strong>Time:</strong> {task.time}</p>
//                 <p className="card-text"><strong>Location:</strong> {task.location}</p>
//                 <p className="card-text"><strong>Priority:</strong> {task.important}</p>
//                 <button className="btn btn-warning mr-2" onClick={() => setTaskToEdit(task)}>Edit</button>
//                 <button className="btn btn-danger" onClick={() => deleteTask(task)}>Delete</button>
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>
//       <Link to="/add-task">
//         <button className="btn btn-primary">Add new Task</button>
//       </Link>
//       <Routes>
//         <Route path="/add-task" element={<AddTask />} />
//       </Routes>
//     </div>
//   );
// };

// export default TaskList;




import React from 'react';
import { Link, Route, Routes, useNavigate } from 'react-router-dom';
import AddTask from './AddTask';
import '../style.css';

const TaskList = ({ tasks, searchQuery, setSearchQuery, deleteTask, setTaskToEdit, markAsComplete, toggleDarkMode, darkMode }) => {
  const navigate = useNavigate();

  // Sort tasks by due date
  const sortedTasks = tasks.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));

  // Filter tasks based on search query
  const filteredTasks = sortedTasks.filter(task => 
    (task.taskName && task.taskName.toLowerCase().includes(searchQuery.toLowerCase())) || 
    (task.description && task.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Find the next task to be completed
  const nextTask = sortedTasks.find(task => !task.completed);

  const handleEdit = (task) => {
    setTaskToEdit(task);
    navigate('/add-task');
  };



  return (
    <div className="container mt-4">
      <div className='search-bar mb-3'>
        
        <input type="text" className="form-control" placeholder="Search tasks..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
        <button onClick={toggleDarkMode} className='btn btn-secondary ml-2'>{darkMode ? 'Light Mode' : 'Dark Mode'}</button>
      </div>
      <h1 className='mb-4'>All Tasks</h1>
      <div className="row" >
        {filteredTasks.map((task, index) => (
          <div className={`col-md-4 mb-4  ${task === nextTask ? 'highlight' : ''}`} key={index}>
            <div className="card h-100">
              <div className="card-body d-flex flex-column">
                <h5 className="card-title">{task.taskName}</h5>
                <p className="card-text">{task.description}</p>
                <p className="card-text"><strong>Due Date:</strong> {task.dueDate}</p>
                <p className="card-text"><strong>Time:</strong> {task.time}</p>
                <p className="card-text"><strong>Location:</strong> {task.location}</p>
                <p className="card-text"><strong>Priority:</strong> {task.important}</p>
                <div className='mt-auto button-group'>
                <button className="btn btn-warning mr-2" onClick={() => handleEdit(task)}><i className='fas fa-edit'></i>Edit</button>
                <button className="btn btn-danger mr-2" onClick={() => deleteTask(task)}><i className="fas fa-trash-alt"></i>Delete</button>
                <button className="btn btn-success" onClick={() => markAsComplete(task)}><i className='fas fa-check'></i>Mark as Complete</button>
              </div></div>
            </div>
          </div>
        ))}
      </div>
      <div className='d-flex justify-content-between mt-4'>
      <Link to="/add-task">
        <button className="btn btn-primary"><i className='fas fa-plus'></i>Add new Task</button>
      </Link>
      <Link to="/completed-tasks">
        <button className="btn btn-secondary"><i className='fas fa-tasks'></i>View Completed Tasks</button>
      </Link>
      <Routes>
        <Route path="/add-task" element={<AddTask />} />
      </Routes>
    </div></div>
  );
};

export default TaskList;
